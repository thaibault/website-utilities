import { DomNodes as BaseDomNodes, FirstParameter, Mapping, Options as BaseOptions, ProcedureFunction, $T } from 'clientnode';
import { Options as InternationalisationOptions } from 'internationalisation/type';
import { SpinnerOptions } from 'spin.js';
import WebsiteUtilities from './index';
export type WebsiteUtilitiesFunction = ((..._parameters: Array<unknown>) => unknown) & {
    class: typeof WebsiteUtilities;
};
declare global {
    interface JQueryStatic {
        WebsiteUtilities: WebsiteUtilitiesFunction;
    }
    const dataLayer: Array<unknown>;
}
export type DomNodes<Type = string> = BaseDomNodes<Type> & {
    mediaQueryIndicator: Type;
    scrollToTopButton: Type;
    startUpAnimationClassPrefix: Type;
    top: Type;
    windowLoadingCover: Type;
    windowLoadingSpinner: Type;
};
export interface DefaultOptions {
    activateLanguageSupport: boolean;
    additionalPageLoadingTimeInMilliseconds: number;
    domain: string;
    domNodes: DomNodes;
    domNodeSelectorInfix: null | string;
    domNodeSelectorPrefix: string;
    initialSectionName: string;
    knownScrollEventNames: Array<string>;
    language: Partial<InternationalisationOptions>;
    mediaQueryClassNameIndicator: Array<Array<string>>;
    name: string;
    onChangeMediaQueryMode: ProcedureFunction;
    onChangeToExtraSmallMode: ProcedureFunction;
    onChangeToLargeMode: ProcedureFunction;
    onChangeToMediumMode: ProcedureFunction;
    onChangeToSmallMode: ProcedureFunction;
    onStartUpAnimationComplete: ProcedureFunction;
    onSwitchSection: ProcedureFunction;
    onViewportMovesAwayFromTop: ProcedureFunction;
    onViewportMovesToTop: ProcedureFunction;
    scrollToTop: {
        button: {
            hideAnimationOptions: JQuery.EffectsOptions<HTMLElement>;
            showAnimationOptions: JQuery.EffectsOptions<HTMLElement>;
            slideDistanceInPixel: number;
        };
        options: JQuery.EffectsOptions<HTMLElement>;
    };
    startUpAnimationElementDelayInMilliseconds: number;
    startUpHide: Mapping<number | string>;
    startUpShowAnimation: FirstParameter<$T['animate']>;
    switchToManualScrollingIndicator: (event: JQuery.Event) => boolean;
    tracking?: {
        buttonClick?: (this: WebsiteUtilities, $link: $T<HTMLButtonElement>, event: JQuery.Event) => void;
        linkClick?: (this: WebsiteUtilities, $link: $T<HTMLLinkElement>, event: JQuery.Event) => void;
        sectionSwitch?: (this: WebsiteUtilities, sectionName: string) => void;
        track: (item: TrackingItem) => void;
    };
    windowLoadingCoverHideAnimation: FirstParameter<$T['animate']>;
    windowLoadingSpinner: SpinnerOptions;
    windowLoadedTimeoutAfterDocLoadedInMSec: number;
}
export type Options = BaseOptions & DefaultOptions;
export interface TrackingItem {
    context: string;
    event: string;
    eventType: string;
    icon?: string;
    label: string;
    reference: string;
    subject: string;
    value: number;
    userInteraction: boolean;
}
