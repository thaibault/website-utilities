export interface DefaultOptions {
    additionalPageLoadingTimeInMilliseconds: number;
    domain: string;
    initialSectionName: string;
    knownScrollEventNames: Array<string>;
    mediaQueryClassNameIndicator: Array<Array<string>>;
    sectionNames: Array<string>;
    selectors: {
        top: string;
        scrollToTopButtons: string;
        section: string;
        startUpAnimationClassPrefix: string;
        windowLoadingCover: string;
    };
    startUpAnimationElementDelayInMilliseconds: number;
    tracking: boolean;
    windowLoadedTimeoutAfterDocLoadedInMSec: number;
}
export type Options = DefaultOptions;
export interface TrackingItem {
    context?: string;
    event: string;
    eventType: string;
    icon?: string;
    label: string;
    reference: string;
    subject: string;
    value?: number;
    userInteraction: boolean;
}
