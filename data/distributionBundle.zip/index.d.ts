import { Logger, Mapping } from 'clientnode';
import { WebComponentAPI } from 'web-component-wrapper/type';
import { Web } from 'web-component-wrapper/Web';
import { DefaultOptions, Options, TrackingItem } from './type';
export declare const log: Logger;
/**
 * This plugin holds all needed methods to extend a whole website.
 * @property _defaultOptions - Options extended by the options given to the
 * initializer method.
 * @property _defaultOptions.additionalPageLoadingTimeInMilliseconds -
 * Additional time to wait until page will be indicated as loaded.
 * @property _defaultOptions.initialSectionName - Pre-selected section name.
 * @property _defaultOptions.knownScrollEventNames - Saves all known scroll
 * events in a space separated string.
 * @property _defaultOptions.language - Options for client side
 * internationalization handler.
 * @property _defaultOptions.mediaQueryClassNameIndicator - Mapping of media
 * query class indicator names to internal event names.
 * @property _defaultOptions.selectors - Mapping of dom node descriptions to
 * their corresponding selectors.
 * @property _defaultOptions.selectors.top - Selector to indicate that viewport
 * is currently on top.
 * @property _defaultOptions.selectors.scrollToTopButtons - Selectors for
 * starting an animated scroll to top.
 * @property _defaultOptions.selectors.startUpAnimationClassPrefix - Class name
 * selector prefix for all dom nodes to appear during start up animations.
 * @property _defaultOptions.selectors.windowLoadingCover - Selector to the full
 * window loading cover dom node.
 * @property _defaultOptions.startUpAnimationElementDelayInMilliseconds - Delay
 * between two startup animated dom nodes in order.
 * @property _defaultOptions.tracking - Indicates whether tracking should be
 * used or not.
 * @property _defaultOptions.windowLoadedTimeoutAfterDocLoadedInMSec - Duration
 * after loading cover should be removed.
 * @property options - Finally configured given options.
 * @property currentSectionName - Saves current section hash name.
 * @property startUpAnimationIsComplete - Indicates whether start up animations
 * has finished.
 * @property continueAutoScrolling - Indicates whether auto scrolling should
 * continue or not. Gets set to "false" if user wants to scroll manually.
 * @property viewportIsOnTop - Indicates whether current viewport is on top.
 * @property windowLoaded - Indicates whether window is already loaded.
 * @property onChangeMediaQueryMode - Callback to trigger if media query mode
 * changes.
 * @property onChangeToExtraSmallMode - Callback to trigger if media query mode
 * changes to extra small mode.
 * @property onChangeToLargeMode - Callback to trigger if media query mode
 * changes to large mode.
 * @property onChangeToMediumMode - Callback to trigger if media query mode
 * changes to medium mode.
 * @property onChangeToSmallMode - Callback to trigger if media query mode
 * changes to small mode.
 * @property onStartUpAnimationComplete - Callback to trigger if all start up
 * animations has finished.
 * @property onSwitchSection - Callback to trigger if current section switches.
 * @property onViewportMovesAwayFromTop - Callback to trigger when viewport
 * moves away from top.
 * @property onViewportMovesToTop - Callback to trigger when viewport arrives
 * at top.
 * @property onSwitchToManualScrollingIndicator - Indicator
 * function to stop currently running scroll animations to let the user get
 * control of current scrolling behavior. Given callback gets an event object.
 * If the function returns "true" current animated scrolls will be stopped.
 * @property onButtonClick - Function to call on button click events.
 * @property onLinkClick - Function to call on link click events.
 * @property onSectionSwitch - Function to call on section switches.
 * @property onTrack - Tracker call itself.
 */
export declare class WebsiteUtilities<TElement = HTMLElement, ExternalProperties extends Mapping<unknown> = Mapping<unknown>, InternalProperties extends Mapping<unknown> = Mapping<unknown>> extends Web<TElement, ExternalProperties, InternalProperties> {
    static _name: string;
    static _defaultOptions: DefaultOptions;
    readonly self: typeof WebsiteUtilities;
    options: Options;
    onChangeMediaQueryMode: (this: WebsiteUtilities, oldMediaQueryMode: string, newMediaQueryMode: string, event?: Event) => void;
    onChangeToExtraSmallMode: (this: WebsiteUtilities, oldMediaQueryMode: string, event?: Event) => void;
    onChangeToLargeMode: (this: WebsiteUtilities, oldMediaQueryMode: string, event?: Event) => void;
    onChangeToMediumMode: (this: WebsiteUtilities, oldMediaQueryMode: string, event?: Event) => void;
    onChangeToSmallMode: (this: WebsiteUtilities, oldMediaQueryMode: string, event?: Event) => void;
    onStartUpAnimationComplete: (this: WebsiteUtilities) => void;
    onSwitchSection: (this: WebsiteUtilities, event?: Event) => void;
    onViewportMovesAwayFromTop: (this: WebsiteUtilities, event?: Event) => void;
    onViewportMovesToTop: (this: WebsiteUtilities, event?: Event) => void;
    onSwitchToManualScrollingIndicator: (event: Event) => boolean;
    onLoaded: () => void;
    onButtonClick: (this: WebsiteUtilities, event: Event) => void;
    onSectionSwitch: (this: WebsiteUtilities, sectionName: string, _oldSectionName: string, _event?: Event) => Promise<void>;
    onLinkClick: (this: WebsiteUtilities, event: Event) => void;
    onTrack: (this: WebsiteUtilities, item: TrackingItem) => Promise<void>;
    currentSectionName: string;
    startUpAnimationIsComplete: boolean;
    continueAutoScrolling: boolean;
    viewportIsOnTop: boolean | undefined;
    windowLoaded: boolean;
    scrollToTopButtonDomNodes: NodeListOf<HTMLElement> | null;
    sectionDomNode: HTMLElement | null;
    sectionDomNodes: Mapping<HTMLElement>;
    topDomNode: HTMLElement | null;
    windowLoadingCoverDomNode: HTMLElement | null;
    /**
     * Defines dynamic getter and setter interface and resolves configuration
     * object. Initializes the map implementation.
     */
    constructor();
    /**
     * Triggered when ever a given attribute has changed and triggers to update
     * configured dom content.
     * @param name - Attribute name which was updates.
     * @param newValue - New updated value.
     */
    onUpdateAttribute(name: string, newValue: string): void;
    /**
     * Updates controlled dom elements.
     * @param reason - Why an update has been triggered.
     */
    render(reason?: string): Promise<void>;
    grabDomNodes(): void;
    /**
     * Scrolls to top of page smoothly via being interruptible.
     */
    interruptableScrollToTop(): void;
    /**
     * Scrolls to top of page smoothly.
     */
    scrollToTop(): void;
    /**
     * This method disables scrolling on the given web view.
     */
    disableScrolling(): void;
    /**
     * This method disables scrolling on the given web view.
     */
    enableScrolling(): void;
    /**
     * Triggers an analytics event. All given arguments are forwarded to
     * configured analytics event code to defined their environment variables.
     * @param properties - Event tracking information.
     */
    track(properties: Omit<TrackingItem, 'context' | 'value'> & {
        context?: string;
        value?: number;
    }): Promise<void>;
    /**
     * This method triggers if the viewport moves to top.
     */
    _onViewportMovesToTop(): void;
    /**
     * This method triggers if the viewport moves away from top.
     */
    _onViewportMovesAwayFromTop(): Promise<void>;
    /**
     * This method triggers if we change the current section.
     * @param sectionName - Contains the new section name.
     * @param event - Optional event which triggered the switch.
     */
    switchSection(sectionName: string, event?: Event): Promise<void>;
    /**
     * Handle section switches.
     * @returns Promise resolving when routing initialization has been
     * finished.
     */
    _initializeRouting(): Promise<void>;
    /**
     * Removes class names from scroll to top buttons to stop running
     * transitions.
     * @param classNames - Optional class names to remove.
     */
    _finishScrollToTopButtonTransition(classNames?: Array<string> | string): void;
    /**
     * This method triggers if view port arrives at special areas.
     */
    _bindScrollEvents(): void;
    /**
     * This method triggers after window is loaded.
     * @returns Promise resolving to nothing when loading cover has been
     * removed.
     */
    _removeLoadingCover(): Promise<void>;
    /**
     * This method handles the given start up effect step.
     * @returns Promise resolving to nothing when start up effects have been
     * finished.
     */
    _performStartUpEffects(): Promise<void>;
    /**
     * This method adds triggers to switch section.
     */
    _bindNavigationEvents(): void;
    /**
     * Adds trigger to scroll top buttons.
     */
    _bindScrollToTopButton(): void;
    /**
     * Executes the page tracking code.
     */
    _bindClickTracking(): void;
}
export declare const api: WebComponentAPI<HTMLElement, Mapping<unknown>, Mapping<unknown>, typeof Web>;
export default WebsiteUtilities;
