import { $DomNodes, RecursivePartial, Tools } from 'clientnode';
import Internationalisation from 'internationalisation';
import { Spinner } from 'spin.js';
import { DefaultOptions, Options, TrackingItem } from './type';
/**
 * This plugin holds all needed methods to extend a whole website.
 * @property _defaultOptions - Options extended by the options given to the
 * initializer method.
 * @property _defaultOptions.activateLanguageSupport - Indicates whether
 * language support should be used or not.
 * @property _defaultOptions.additionalPageLoadingTimeInMilliseconds -
 * Additional time to wait until page will be indicated as loaded.
 * @property _defaultOptions.domNodes - Mapping of dom node descriptions to
 * their corresponding selectors.
 * @property _defaultOptions.domNodes.mediaQueryIndicator - Selector for
 * indicator dom node to use to trigger current media query mode.
 * @property _defaultOptions.domNodes.top - Selector to indicate that viewport
 * is currently on top.
 * @property _defaultOptions.domNodes.scrollToTopButton - Selector for
 * starting an animated scroll to top.
 * @property _defaultOptions.domNodes.startUpAnimationClassPrefix - Class name
 * selector prefix for all dom nodes to appear during start up animations.
 * @property _defaultOptions.domNodes.windowLoadingCover - Selector to the full
 * window loading cover dom node.
 * @property _defaultOptions.domNodes.windowLoadingSpinner - Selector to the
 * window loading spinner (on top of the window loading cover).
 * @property _defaultOptions.domNodeSelectorInfix - Selector infix for all
 * nodes to take into account.
 * @property _defaultOptions.domNodeSelectorPrefix - Selector prefix for all
 * nodes to take into account.
 * @property _defaultOptions.initialSectionName - Pre-selected section name.
 * @property _defaultOptions.knownScrollEventNames - Saves all known scroll
 * events in a space separated string.
 * @property _defaultOptions.language - Options for client side
 * internationalisation handler.
 * @property _defaultOptions.mediaQueryClassNameIndicator - Mapping of media
 * query class indicator names to internal event names.
 * @property _defaultOptions.onChangeMediaQueryMode - Callback to trigger if
 * media query mode changes.
 * @property _defaultOptions.onChangeToExtraSmallMode - Callback to trigger if
 * media query mode changes to extra small mode.
 * @property _defaultOptions.onChangeToLargeMode - Callback to trigger if media
 * query mode changes to large mode.
 * @property _defaultOptions.onChangeToMediumMode - Callback to trigger if
 * media query mode changes to medium mode.
 * @property _defaultOptions.onChangeToSmallMode - Callback to trigger if media
 * query mode changes to small mode.
 * @property _defaultOptions.onStartUpAnimationComplete - Callback to trigger
 * if all start up animations has finished.
 * @property _defaultOptions.onSwitchSection - Callback to trigger if current
 * section switches.
 * @property _defaultOptions.onViewportMovesAwayFromTop - Callback to trigger
 * when viewport moves away from top.
 * @property _defaultOptions.onViewportMovesToTop - Callback to trigger when
 * viewport arrives at top.
 * @property _defaultOptions.scrollToTop - Options for automated scroll top
 * animation.
 * @property _defaultOptions.scrollToTop.button - To top scroll button behavior
 * configuration.
 * @property _defaultOptions.scrollToTop.button.hideAnimationOptions -
 * Configures hide animation.
 * @property _defaultOptions.scrollToTop.button.showAnimationOptions -
 * Configures show animation.
 * @property _defaultOptions.scrollToTop.options - Scrolling animation options.
 * @property _defaultOptions.startUpAnimationElementDelayInMilliseconds - Delay
 * between two startup animated dom nodes in order.
 * @property _defaultOptions.startUpHide - Options for initially hiding dom
 * nodes showing on startup later.
 * @property _defaultOptions.startUpShowAnimation - Options for startup show in
 * animation.
 * @property _defaultOptions.switchToManualScrollingIndicator - Indicator
 * function to stop currently running scroll animations to let the user get
 * control of current scrolling behavior. Given callback gets an event object.
 * If the function returns "true" current animated scrolls will be stopped.
 * @property _defaultOptions.tracking - Tracking configuration to collect
 * user's behavior data.
 * @property _defaultOptions.tracking.buttonClick - Function to call on button
 * click events.
 * @property _defaultOptions.tracking.linkClick - Function to call on link
 * click events.
 * @property _defaultOptions.tracking.sectionSwitch - Function to call on
 * section switches.
 * @property _defaultOptions.tracking.track - Tracker call itself.
 * @property _defaultOptions.windowLoadingCoverHideAnimation - Options for
 * startup loading cover hide animation.
 * @property _defaultOptions.windowLoadingSpinner - Options for the window
 * loading cover spinner.
 * @property _defaultOptions.windowLoadedTimeoutAfterDocLoadedInMSec - Duration
 * after loading cover should be removed.
 * @property options - Finally configured given options.
 * @property $domNodes - Saves a set of references to all needed dom nodes.
 * @property currentMediaQueryMode - Saves current media query status depending
 * on available space in current browser window.
 * @property currentSectionName - Saves current section hash name.
 * @property languageHandler - Reference to the language switcher instance.
 * @property startUpAnimationIsComplete - Indicates whether start up animations
 * has finished.
 * @property viewportIsOnTop - Indicates whether current viewport is on top.
 * @property windowLoaded - Indicates whether window is already loaded.
 * @property windowLoadingSpinner - The window loading spinner instance.
 */
export declare class WebsiteUtilities extends Tools {
    static _defaultOptions: DefaultOptions;
    options: Options;
    $domNodes: $DomNodes;
    currentMediaQueryMode: string;
    currentSectionName: string;
    languageHandler: Internationalisation | null;
    startUpAnimationIsComplete: boolean;
    viewportIsOnTop: boolean;
    windowLoaded: boolean;
    windowLoadingSpinner: null | Spinner;
    /**
     * Initializes the interactive web application.
     * @param options - An options object.
     * @returns Returns a promise containing the current instance.
     */
    initialize<R = Promise<WebsiteUtilities>>(options?: RecursivePartial<Options>): R;
    /**
     * Scrolls to top of page. Runs the given function after viewport arrives.
     * @returns Returns the current instance.
     */
    scrollToTop(): this;
    /**
     * This method disables scrolling on the given web view.
     * @returns Returns the current instance.
     */
    disableScrolling(): this;
    /**
     * This method disables scrolling on the given web view.
     * @returns Returns the current instance.
     */
    enableScrolling(): this;
    /**
     * Triggers an analytics event. All given arguments are forwarded to
     * configured analytics event code to defined their environment variables.
     * @param properties - Event tracking information.
     * @returns Returns the current instance.
     */
    track(properties: Omit<TrackingItem, 'context' | 'value'> & {
        context?: string;
        value?: number;
    }): this;
    /**
     * This method triggers if the viewport moves to top.
     * @returns Nothing.
     */
    _onViewportMovesToTop: (...parameters: Array<unknown>) => Promise<void>;
    /**
     * This method triggers if the viewport moves away from top.
     * @returns Nothing.
     */
    _onViewportMovesAwayFromTop: (...parameters: Array<unknown>) => Promise<void>;
    /**
     * This method triggers if the responsive design switches to another mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     */
    _onChangeMediaQueryMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if the responsive design switches to large mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     */
    _onChangeToLargeMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if the responsive design switches to medium mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     */
    _onChangeToMediumMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if the responsive design switches to small mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     */
    _onChangeToSmallMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if the responsive design switches to extra small
     * mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     */
    _onChangeToExtraSmallMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if we change the current section.
     * @param sectionName - Contains the new section name.
     */
    _onSwitchSection(sectionName: string): void;
    /**
     * This method is complete if last startup animation was initialized.
     */
    _onStartUpAnimationComplete(): Promise<void> | void;
    /**
     * This method adds triggers for responsive design switches.
     */
    _bindMediaQueryChangeEvents(): void;
    /**
     * This method triggers if the responsive design switches its mode.
     * @param parameters - All arguments will be appended to the event handler
     * callbacks.
     */
    _triggerWindowResizeEvents(...parameters: Array<unknown>): void;
    /**
     * This method triggers if view port arrives at special areas.
     * @param parameters - All arguments will be appended to the event handler
     * callbacks.
     */
    _bindScrollEvents(...parameters: Array<unknown>): void;
    /**
     * This method triggers after window is loaded.
     * @returns Promise resolving to nothing when loading cover has been
     * removed.
     */
    _removeLoadingCover(): Promise<void>;
    /**
     * This method handles the given start up effect step.
     * @param elementNumber - The current startup step.
     * @returns Promise resolving to nothing when start up effects have been
     * finished.
     */
    _performStartUpEffects(elementNumber?: number): Promise<void>;
    /**
     * This method adds triggers to switch section.
     */
    _bindNavigationEvents(): void;
    /**
     * Adds trigger to scroll top buttons.
     */
    _bindScrollToTopButton(): void;
    /**
     * Executes the page tracking code.
     */
    _bindClickTracking(): void;
}
export default WebsiteUtilities;
