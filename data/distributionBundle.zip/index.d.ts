import Tools from 'clientnode';
import { RecursivePartial, $DomNodes } from 'clientnode/type';
import Internationalisation from 'internationalisation';
import { Spinner } from 'spin.js';
import { DefaultOptions, Options, TrackingItem } from './type';
/**
 * This plugin holds all needed methods to extend a whole website.
 * @property static:_defaultOptions - Options extended by the options given to
 * the initializer method.
 * @property static:_defaultOptions.activateLanguageSupport - Indicates whether
 * language support should be used or not.
 * @property static:_defaultOptions.additionalPageLoadingTimeInMilliseconds -
 * Additional time to wait until page will be indicated as loaded.
 * @property static:_defaultOptions.domNodes - Mapping of dom node descriptions
 * to their corresponding selectors.
 * @property static:_defaultOptions.domNodes.mediaQueryIndicator - Selector for
 * indicator dom node to use to trigger current media query mode.
 * @property static:_defaultOptions.domNodes.top - Selector to indicate that
 * viewport is currently on top.
 * @property static:_defaultOptions.domNodes.scrollToTopButton - Selector for
 * starting an animated scroll to top.
 * @property static:_defaultOptions.domNodes.startUpAnimationClassPrefix -
 * Class name selector prefix for all dom nodes to appear during start up
 * animations.
 * @property static:_defaultOptions.domNodes.windowLoadingCover - Selector to
 * the full window loading cover dom node.
 * @property static:_defaultOptions.domNodes.windowLoadingSpinner - Selector to
 * the window loading spinner (on top of the window loading cover).
 * @property static:_defaultOptions.domNodeSelectorInfix - Selector infix for
 * all nodes to take into account.
 * @property static:_defaultOptions.domNodeSelectorPrefix - Selector prefix for
 * all nodes to take into account.
 * @property static:_defaultOptions.initialSectionName - Pre-selected section
 * name.
 * @property static:_defaultOptions.knownScrollEventNames - Saves all known
 * scroll events in a space separated string.
 * @property static:_defaultOptions.language - Options for client side
 * internationalisation handler.
 * @property static:_defaultOptions.mediaQueryClassNameIndicator - Mapping of
 * media query class indicator names to internal event names.
 * @property static:_defaultOptions.onChangeMediaQueryMode - Callback to
 * trigger if media query mode changes.
 * @property static:_defaultOptions.onChangeToExtraSmallMode - Callback to
 * trigger if media query mode changes to extra small mode.
 * @property static:_defaultOptions.onChangeToLargeMode - Callback to trigger
 * if media query mode changes to large mode.
 * @property static:_defaultOptions.onChangeToMediumMode - Callback to trigger
 * if media query mode changes to medium mode.
 * @property static:_defaultOptions.onChangeToSmallMode - Callback to trigger
 * if media query mode changes to small mode.
 * @property static:_defaultOptions.onStartUpAnimationComplete - Callback to
 * trigger if all start up animations has finished.
 * @property static:_defaultOptions.onSwitchSection - Callback to trigger if
 * current section switches.
 * @property static:_defaultOptions.onViewportMovesAwayFromTop - Callback to
 * trigger when viewport moves away from top.
 * @property static:_defaultOptions.onViewportMovesToTop - Callback to trigger
 * when viewport arrives at top.
 * @property static:_defaultOptions.scrollToTop - Options for automated scroll
 * top animation.
 * @property static:_defaultOptions.scrollToTop.button - To top scroll button
 * behavior configuration.
 * @property static:_defaultOptions.scrollToTop.button.hideAnimationOptions -
 * Configures hide animation.
 * @property static:_defaultOptions.scrollToTop.button.showAnimationOptions -
 * Configures show animation.
 * @property static:_defaultOptions.scrollToTop.options - Scrolling animation
 * options.
 * @property static:_defaultOptions.startUpAnimationElementDelayInMiliseconds -
 * Delay between two startup animated dom nodes in order.
 * @property static:_defaultOptions.startUpHide - Options for initially hiding
 * dom nodes showing on startup later.
 * @property static:_defaultOptions.startUpShowAnimation - Options for startup
 * show in animation.
 * @property static:_defaultOptions.switchToManualScrollingIndicator -
 * Indicator function to stop currently running scroll animations to let the
 * user get control of current scrolling behavior. Given callback gets an event
 * object. If the function returns "true" current animated scrolls will be
 * stopped.
 * @property static:_defaultOptions.tracking - Tracking configuration to
 * collect user's behavior data.
 * @property static:_defaultOptions.tracking.buttonClick - Function to call on
 * button click events.
 * @property static:_defaultOptions.tracking.linkClick - Function to call on
 * link click events.
 * @property static:_defaultOptions.tracking.sectionSwitch - Function to call
 * on section switches.
 * @property static:_defaultOptions.tracking.track - Tracker call itself.
 * @property static:_defaultOptions.windowLoadingCoverHideAnimation - Options
 * for startup loading cover hide animation.
 * @property static:_defaultOptions.windowLoadingSpinner - Options for the
 * window loading cover spinner.
 * @property static:_defaultOptions.windowLoadedTimeoutAfterDocLoadedInMSec -
 * Duration after loading cover should be removed.
 *
 * @property options - Finally configured given options.
 *
 * @property $domNodes - Saves a set of references to all needed dom nodes.
 *
 * @property currentMediaQueryMode - Saves current media query status depending
 * on available space in current browser window.
 * @property currentSectionName - Saves current section hash name.
 *
 * @property languageHandler - Reference to the language switcher instance.
 *
 * @property startUpAnimationIsComplete - Indicates whether start up animations
 * has finished.
 * @property viewportIsOnTop - Indicates whether current viewport is on top.
 * @property windowLoaded - Indicates whether window is already loaded.
 *
 * @property windowLoadingSpinner - The window loading spinner instance.
 */
export declare class WebsiteUtilities extends Tools {
    static _defaultOptions: DefaultOptions;
    options: Options;
    $domNodes: $DomNodes;
    currentMediaQueryMode: string;
    currentSectionName: string;
    languageHandler: Internationalisation | null;
    startUpAnimationIsComplete: boolean;
    viewportIsOnTop: boolean;
    windowLoaded: boolean;
    windowLoadingSpinner: null | Spinner;
    /**
     * Initializes the interactive web application.
     * @param options - An options object.
     *
     * @returns Returns a promise containing the current instance.
     */
    initialize<R = Promise<WebsiteUtilities>>(options?: RecursivePartial<Options>): R;
    /**
     * Scrolls to top of page. Runs the given function after viewport arrives.
     * @returns Returns the current instance.
     */
    scrollToTop(): WebsiteUtilities;
    /**
     * This method disables scrolling on the given web view.
     * @returns Returns the current instance.
     */
    disableScrolling(): WebsiteUtilities;
    /**
     * This method disables scrolling on the given web view.
     * @returns Returns the current instance.
     */
    enableScrolling(): WebsiteUtilities;
    /**
     * Triggers an analytics event. All given arguments are forwarded to
     * configured analytics event code to defined their environment variables.
     * @param properties - Event tracking informations.
     *
     * @returns Returns the current instance.
     */
    track(properties: Omit<TrackingItem, 'context' | 'value'> & {
        context?: string;
        value?: number;
    }): WebsiteUtilities;
    /**
     * This method triggers if the viewport moves to top.
     * @returns Nothing.
     */
    _onViewportMovesToTop: (..._parameters: unknown[]) => Promise<unknown>;
    /**
     * This method triggers if the viewport moves away from top.
     * @returns Nothing.
     */
    _onViewportMovesAwayFromTop: (..._parameters: unknown[]) => Promise<unknown>;
    /**
     * This method triggers if the responsive design switches to another mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     *
     * @returns Nothing.
     */
    _onChangeMediaQueryMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if the responsive design switches to large mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     *
     * @returns Nothing.
     */
    _onChangeToLargeMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if the responsive design switches to medium mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     *
     * @returns Nothing.
     */
    _onChangeToMediumMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if the responsive design switches to small mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     *
     * @returns Nothing.
     */
    _onChangeToSmallMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if the responsive design switches to extra small
     * mode.
     * @param _oldMode - Saves the previous mode.
     * @param _newMode - Saves the new mode.
     *
     * @returns Nothing.
     */
    _onChangeToExtraSmallMode(_oldMode: string, _newMode: string): void;
    /**
     * This method triggers if we change the current section.
     * @param sectionName - Contains the new section name.
     *
     * @returns Nothing.
     */
    _onSwitchSection(sectionName: string): void;
    /**
     * This method is complete if last startup animation was initialized.
     * @returns Nothing.
     */
    _onStartUpAnimationComplete(): void;
    /**
     * This method adds triggers for responsive design switches.
     * @returns Nothing.
     */
    _bindMediaQueryChangeEvents(): void;
    /**
     * This method triggers if the responsive design switches its mode.
     * @param parameters - All arguments will be appended to the event handler
     * callbacks.
     *
     * @returns Nothing.
     */
    _triggerWindowResizeEvents(...parameters: Array<unknown>): void;
    /**
     * This method triggers if view port arrives at special areas.
     * @param parameters - All arguments will be appended to the event handler
     * callbacks.
     *
     * @returns Nothing.
     */
    _bindScrollEvents(...parameters: Array<unknown>): void;
    /**
     * This method triggers after window is loaded.
     * @returns Promise resolving to nothing when loading cover has been
     * removed.
     */
    _removeLoadingCover(): Promise<void>;
    /**
     * This method handles the given start up effect step.
     * @param elementNumber - The current start up step.
     *
     * @returns Promise resolving to nothing when start up effects have been
     * finished.
     */
    _performStartUpEffects(elementNumber?: number): Promise<void>;
    /**
     * This method adds triggers to switch section.
     * @returns Nothing.
     */
    _bindNavigationEvents(): void;
    /**
     * Adds trigger to scroll top buttons.
     * @returns Nothing.
     */
    _bindScrollToTopButton(): void;
    /**
     * Executes the page tracking code.
     * @returns Nothing.
     */
    _bindClickTracking(): void;
}
export default WebsiteUtilities;
