import { Logger } from 'clientnode';
export declare const PUBLIC_REPOSITORY_PATH: string;
export declare const log: Logger;
